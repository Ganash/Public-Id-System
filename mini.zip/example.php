<html>
<style type="text/css">
#div2{
position:absolute;
width:1349px;
height:250px;
border:1px;
top:200px;
background-color:#3BBA10;font-size:20px;}
#div1{position:absolute;width:1349px;height:150px;border:1px;background-color:orange;font-size:40px;text-align:center;}
x{position:absolute;left:20px;}
#div5{position:absolute;width:1349px;height:120px;top:520px;border:1px solid;background-color:#F8DA06;}
#div3{position:absolute;right=0px;width:1350px;height:200px;top:450px;}
<body>
</style>
<?php
?>
<body>
<form method="post" action="registration_db.php">
<div id="div1">
<h3 align="center">ONLINE DOCTER APPOINTMENT</h3>
<h5 style="color:blue" align="center">Registration Form</h5>
</div>
<div id="div2">
<table align="center">
<tr>
<td>Email id</td>
<td><input type="text" name="email"></td>
</tr>
<tr>
<td>Name</td>
<td><input type="text" name="name"></td>
</tr>
<tr>
<td>User Name</td>
<td><input type="text" name="uname"></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="password"></td>
</tr>
<tr>
<td>Contact Number</td>
<td><input type="text" name="phoneno"></td>
</tr>
<tr>
<td>Aadhar Number</td>
<td><input type="text" name="ano"></td>
</tr>
<tr>
<td align="center"><input type="submit" name="Register"></td>
<td><input type="reset" name="clear"></td>
</tr>
<tr>
<td align="right"><td><a href="login.php">Login</a></td>
</tr>
</table>
</form>
</div>
<div id="div3">
<marquee scrollamount="5" behavior="scroll">
<h1>Your Happiness is a Reflection of Your Health</h1>
</marquee>
</div>
<div id="div5">
<pre> <h>  
->Book Appointment in online<br>
->Fast Appointment Booking<br>
->Simple And Faster</h></pre>
</div>
</body></html>?>
