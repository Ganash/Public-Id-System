<?php
	$servername = "mysql.hostinger.in";
	$username = "u717124741_mini";
	$password = "ganesh95";
	$db = "mini";
	// Create connection
	$conn = mysqli_connect($servername, $username, $password,$db);

	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	// echo "Connected successfully";
?>